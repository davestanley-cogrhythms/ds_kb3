
General library of functions I plan to use across different projects.
