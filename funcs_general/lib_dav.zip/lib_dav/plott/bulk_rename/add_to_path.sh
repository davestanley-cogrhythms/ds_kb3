
# Note: Run this command by typing source add_to_path.sh
PATH=`pwd`:$PATH
