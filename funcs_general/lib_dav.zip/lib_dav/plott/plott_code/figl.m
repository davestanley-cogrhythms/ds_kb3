
function figl(varargin)
% figl (no arguments)
% Opens a large figure

%figure('Position', [ 81         332        1360         474],'Color','w'); % Top half screen
%figure('Position', [ 81           1        1355         805],'Color','w'); % Full screen


figure('units','normalized','outerposition',[0 0 1 1],'Color','w',varargin{:});

end