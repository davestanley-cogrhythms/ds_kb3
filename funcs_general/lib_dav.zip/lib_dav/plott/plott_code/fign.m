
function fign
% fign (no arguments)
% Opens a narrow figure

%figure('Position', [ 587   250   384   556],'Color','w'); % Top half screen
%figure('Position', [ 586   189   456   757],'Color','w'); % Top half screen
% figure('Position', [ 425     1   617   805],'Color','w'); % Top half screen
figure('Position', [ 421    60   582   746],'Color','w'); % Top half screen
%figure('Position', [ 81           1        1355         805],'Color','w'); % Full screen

