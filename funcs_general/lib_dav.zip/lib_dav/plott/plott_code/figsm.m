
function figsm
% figsm (no arguments)
% Opens a narrow figure

% figure('Position', [282   334   629   472],'Color','w'); % Top half screen
%figure('Position', [ 81           1        1355         805],'Color','w'); % Full screen
figure('Position',[ 440   536   391   262],'Color','w');