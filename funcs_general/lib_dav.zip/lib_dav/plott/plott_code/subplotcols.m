
function h=subplotcols(N,i)
%     h=subplotcols(N,i)
% 
%     Wrapper shortcut for producing subplots in arranged
%     in columns (see code below)

h=subplot(1,N,i);
end