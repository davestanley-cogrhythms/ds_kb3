
function h=subplotrows(N,i)
%     h=subplotrows(N,i)
% 
%     Wrapper shortcut for producing subplots in arranged
%     in rows (see code below)

h=subplot(N,1,i);
end