

addpath(genpath(pwd));
