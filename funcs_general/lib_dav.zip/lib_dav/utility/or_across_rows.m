
function out = or_across_rows(in)

    out=logical(sum(in,2));

end
