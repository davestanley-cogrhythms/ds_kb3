

function curr_foldername = get_curr_foldername

    [a curr_foldername c] = fileparts(pwd);

end

